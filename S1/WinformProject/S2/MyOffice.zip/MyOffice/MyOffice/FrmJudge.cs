﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyOffice
{
    public partial class FrmJudge : Form
    {
        //填写评价的窗体类
        //保存父窗体的实例
        private FrmShow myParent;
        //要评价的员工对象
        private SE se;
        //父窗体的实例、被评分的员工在员工数组中的位置
        public FrmJudge(FrmShow frmShow, int index)
        {
            InitializeComponent();
            this.myParent = frmShow;
            this.se = frmShow.se[index];
        }
    }
}
