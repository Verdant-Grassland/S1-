﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyOffice
{
    public class SE
    {
        //编号访问器
        public int Id { get; set; }
        //姓名访问器
        public string Name { get; set; }
        //年龄访问器
        public int Age { get; set; }
        //评价访问器
        public string Judgement { get; set; }
        //年度等分访问器
        public int Score { get; set; }
    }
}
